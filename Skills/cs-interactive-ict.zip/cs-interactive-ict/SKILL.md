---
name: cs-interactive-ict
description: Turns a raw CS lesson (pasted text or an uploaded lesson file, not pre-split into sections) into a detailed MASTER PROMPT for a separate AI coding agent to build a single-file, interactive HTML teaching site with clickable/animated SVG explanations. Tailored for the EGYPT-ICT-HUB project with bilingual AR/EN toggle, scrollable navbar, logo linking to home, and end-of-lesson exercise reveal pattern. Use whenever Bilal hands over lesson content for this project and wants an interactive explainer site, references building a "موقع تفاعلي" or "interactive explainer", or invokes /cs-interactive-ict. Always run the full staged Q&A before generating the prompt — do NOT skip straight to writing the master prompt from the raw content alone. This is NOT the cs-weekly-self-learning skill and does not reuse its templates or file structure.
---

# CS Interactive Explainer — EGYPT-ICT-HUB Edition

Produces a MASTER PROMPT (not the website itself) that Bilal sends to a separate AI coding agent, which then builds a single self-contained HTML file he presents from in class (desktop + projector). He is a CS educator for students aged 12–17.

Read `references/design-system.md` and `references/svg-technical-rules.md` before writing the final master prompt — they contain the non-negotiable visual and technical requirements that must be embedded in it. Read `references/code-playground.md` whenever the lesson contains runnable code (Python, JavaScript, HTML/CSS, etc.) — it specifies the mandatory editable code panels with real Run output and friendly error panels. Read `references/question-flow.md` for the exact Q&A script to run with Bilal.

Committing and pushing is default behavior: commit AND push the files for every completed deliverable unless Bilal explicitly says otherwise. Do not wait to be asked.

## Workflow

### 1. Get the content
Accept either pasted text or an uploaded lesson file. Content may be a full raw lesson, not pre-split into sections. If the content is unusually long and structurally suggests more than one lesson bundled together (e.g. duplicate slide numbering, multiple distinct "Topic" headers), flag this to Bilal and ask the single pivotal question of whether to split into multiple sites or build one long combined site — this is a high-leverage architectural decision worth asking about even when minimizing questions elsewhere.

When the content arrives as a `.txt` file, treat it as the **English source of truth**. The file typically contains the raw lesson text (definitions, examples, questions) in English, often sourced from a textbook. The site must be built in two language layers from this single source:

**Layer 1 — English content (primary, verbatim from the .txt):**
- All core definitions, explanations, example descriptions, and exercise questions are taken **word-for-word** from the `.txt` file. Do not paraphrase or replace them with invented English.
- Add educational scaffolding on top: intro paragraphs, analogies, "why it matters" bridges, and section transitions — these are written in English by the AI agent (they are not in the .txt) and should match the same explanatory tone.
- The result is a fully English page that preserves the textbook's exact terminology while being enriched for classroom presentation.

**Layer 2 — Arabic content (translation of Layer 1):**
- Translate **everything** from Layer 1 into Egyptian Arabic dialect (مصري), not Modern Standard Arabic (فصحى). The tone should be casual, spoken, and easy for students aged 12–17 to follow — like a friendly teacher explaining to the class.
- Preserve all English CS terms in English (do not transliterate them). Wrap them in `<span dir="ltr">` for correct bidi rendering. Prepend "الـ" before any English term that starts a line, heading, list item, or table cell (per the bidi rule in `references/design-system.md`).
- The `data-ar` attribute holds the Egyptian Arabic text; the `data-en` attribute holds the verbatim English from Layer 1 (or its added-scaffolding English equivalent). The visible inner text defaults to Arabic.
- Do NOT mix English and Arabic arbitrarily inside `data-ar`/`data-en` values. Each attribute must be a clean, complete sentence in its language.

**End-of-lesson questions → MCQ conversion:**
- Any question block at the end of the lesson (after all sections, usually labeled "Exercise", "Warm Up", "Answer the following questions", or their Arabic equivalents) must be converted to **multiple-choice format** with 4 options (A, B, C, D).
- The question text itself stays verbatim from the `.txt` (translated to Arabic for `data-ar`, kept as-is in English for `data-en`).
- The 4 options are derived from the original question's content (e.g. if the original asks "which program displays X", the 4 options are the 4 candidate programs A–D from the textbook).
- Exactly one option is marked correct (using `data-ok="1"` on the correct option's div).
- The answer explanation is written in Egyptian Arabic (for `data-ar`) and English (for `data-en`), explaining *why* the correct answer is right and optionally why the others are wrong.
- These MCQ exercises use the **self-work-then-reveal** pattern (single "اعرض كل الإجابات" button), NOT per-question immediate color feedback — per `references/design-system.md`.

### 2. Propose a section breakdown
Read the content and propose a section breakdown (one section per teachable concept). Show it as a numbered list and ask Bilal to confirm or adjust before continuing. Do not proceed to Q&A until he confirms.

### 3. Check for a resume-in-progress file
Before starting Q&A, run `scripts/resume_check.py` against the content (see script header for usage). If a progress file already exists for this content, ask Bilal: "لقيت شغل سابق على الموضوع ده، تكمل ولا تبدأ من جديد؟" If he wants to resume, skip straight to the first unanswered section.

### 4. Staged Q&A, one stage per section — OR skip to direct authoring
Follow the exact question set in `references/question-flow.md` for each confirmed section by default. However, Bilal has an explicit standing preference for fewer, more pivotal questions and producing the master prompt in a single session — when this is in effect for the current conversation (check for signals like "قللنا الأسئلة" or "اكتب البرومبت علطول"), skip the full per-section Q&A and instead author each section directly using established patterns, prior conventions, and good judgment, reserving questions only for genuinely pivotal forks (e.g. how to split unusually long content). Save progress incrementally either way.

**Immediately after each section's questions are answered**, append the answers to the progress file (see `scripts/resume_check.py` for the save format). Do not hold answers in memory until the end — write as you go, so an interruption only loses the in-progress section.

Use short, clear multiple-choice-style questions where possible, matching how Bilal prefers to be asked. Keep questions batched per section rather than one at a time across the whole lesson.

### 5. Final catch-all
After all sections are done, ask: "عايز تضيف حاجة تانية؟" Capture anything extra and attach it to the relevant section(s) or as general notes for the master prompt.

### 6. Validate before writing the prompt
Run `scripts/validate_answers.py` against the collected answers. It checks that every confirmed section has: a learning objective, at least one example/analogy, at least one common mistake, an interaction type, and an explicit quiz decision (yes-with-count or no). If anything is missing, go back and ask for it — do not generate the master prompt with gaps.

### 7. Write the master prompt
Written primarily in English (technical instructions for the AI coding agent), with Arabic lesson content/examples embedded as-is where relevant. Medium detail level: specific about what each section requires (concept, interaction, examples, mistakes to address, quiz), flexible about exact pixel-level implementation. Must incorporate, as strict non-negotiable requirements (not suggestions):
- Everything in `references/design-system.md` — this includes the code panel LTR fix, activity grid layout, section accent colors, simulation patterns (cart, Teachable Machine, parking, step-by-step, bar chart), common mistakes box, and the runnable code playground rule
- Everything in `references/svg-technical-rules.md` — includes the SVG visual quality rule (vibrant colors, gradients, top-left light source, no flat/dull shapes)
- Everything in `references/code-playground.md` when the lesson has runnable code — every runnable code panel is a live editable playground with ▶ Run output, a friendly error panel (no raw tracebacks), and the Python interpreter/editor-insights embedded verbatim
- The staged build instruction: skeleton → each section individually → final review pass
- Instruction to embed the two logo files from `assets/` (bilal-icon.webp, bilal-wordmark.webp) as base64 in the header/footer
- **Logo must be wrapped in a link pointing to the project root `index.html`** (e.g. `<a href="../../../../index.html" aria-label="الرئيسية">...<img class="nav-logo" ...></a>` for files nested 4 levels deep; adjust the relative path based on actual file depth)
- Auto-generated English-slug filename instruction, derived from the lesson title
- Each section's interaction type must match one of the established patterns from `references/design-system.md` (or a custom one if Bilal specified it during Q&A)
- **Bilingual AR/EN toggle system**: every site must include the toggle mechanism from `references/design-system.md` (EN/AR button, `.lang-toggle` CSS, `data-ar`/`data-en` attributes on every translatable element, `setLang()` JS, `localStorage` persistence, `langChange` event for dynamic content, `refreshOperators()` for operator tables)
- **End-of-lesson exercise pattern**: exercises at the end of the lesson use the self-work-then-reveal pattern — all answers hidden by default, one "اعرض كل الإجابات" button reveals every answer at once. Do NOT use per-question immediate color-feedback for these end-of-lesson exercises; that pattern is reserved for short in-section recall checks only.

Deliver the master prompt two ways: (1) as plain text in the chat reply, and (2) saved as a `.md` file.

### 8. Validate prompt before execution
Before building a website from any master prompt (whether written by Bilal or generated by the skill), run a compatibility check against the design-system and svg-technical-rules references. Verify the prompt includes:
- Dark animated theme with the exact CSS variables from `references/design-system.md`
- Font Cairo, RTL direction, Arabic UI with English technical terms
- No native SVG `<text>` elements (enforced by svg-technical-rules)
- `data-id` attributes on all interactive elements for DOMContentLoaded binding
- At least one interaction simulation pattern from `references/design-system.md` (cart, Teachable Machine, parking, step-by-step, bar chart)
- If the lesson includes runnable code: the code-playground requirements from `references/code-playground.md` — auto-growing editable textareas (full code always visible, no editor scrolling), output shown only after ▶ Run, the friendly error panel (type badge + Arabic hint + line number + source line, NO raw traceback), and a real execution engine per language (Python mini-interpreter, HTML/CSS live iframe, JS console-capture runner, or declared simulated output)
- Base64-embedded logos from `assets/`
- **Logo wrapped in a link to the project root `index.html`**, with the correct relative `href` based on the file's actual depth in the project folder structure
- Header/footer logo `<img>` classes matching the CSS exactly (`.nav-logo` header 36px, `.footer-logo` footer 40px — see `references/design-system.md` Branding)
- Staged build instruction (skeleton → sections → final review)
- Each section ends with a `⚠️ أخطاء شائعة` box
- **End-of-lesson exercises use the self-work-then-reveal pattern** (single "اعرض كل الإجابات" button, answers hidden by default), NOT per-question immediate color feedback
- SVG visual quality: vibrant saturated colors, gradients, highlights, soft shadows, top-left light source, no dull/flat shapes
- Emoji animation: keyframe classes (`.emoji-pulse`, `.emoji-shake`, `.emoji-walk`, `.emoji-float`, `.emoji-glow`) applied to relevant interactive elements (quiz feedback, journey nodes, checklists, error boxes)
- Teaching philosophy: every visual explains concept visually before text, show actions instead of describing them
- **Bilingual toggle**: EN/AR button in the navbar, `.lang-toggle` CSS, `data-ar`/`data-en` on every translatable element, `setLang()` with `localStorage` persistence, `langChange` event dispatch, `refreshOperators()` for dynamic operator tables
- **English source of truth**: when a `.txt` file is provided, its text is the verbatim English source for `data-en` values and core definitions/explanations. The AI agent adds educational scaffolding (intro, analogies, bridges) in English on top of it. The Arabic (`data-ar`) is a translation of the full English content into Egyptian colloquial.
- **End-of-lesson MCQ**: all exercises at the end of the lesson are converted to 4-option MCQ (A/B/C/D), with `data-ok="1"` on the correct option, using the self-work-then-reveal pattern. Distractors are derived from the `.txt` or generated from common mistakes.
- **Bidi compliance**: all English CS terms in the Arabic text are wrapped in `<span dir="ltr">`, and "الـ" is prepended before any English term starting a line/heading/list item/table cell.

If the prompt is missing any of these, annotate it with the missing items and ask Bilal before proceeding — do not build a site from an incompatible prompt.

### 9. Clean up
Once the master prompt has been delivered successfully, delete the progress file created in step 4.

### 10. Commit & push
After every completed deliverable (the master prompt file, and any site built from it), commit the changes with a descriptive message, then push to origin. Default: commit AND push every time unless Bilal explicitly says otherwise — do not wait to be asked.

**Index.html update (mandatory):** Every time a new HTML file is added or a new week folder is created, add a link for it in `index.html` in the correct week slot — interactive link (`🌐 الموقع التفاعلي`) goes above the Speaker Notes link, following the existing pattern. Never skip this step.

## Notes
- If the given content is very long (spans more than one lesson), warn Bilal but do not refuse — proceed with a section breakdown that reflects the full scope.
- Never assume design decisions not covered in `references/design-system.md` — if something is genuinely unspecified and matters for the prompt, ask rather than guess.
- This skill is scoped to the EGYPT-ICT-HUB project. Do not reuse it for other projects without cloning and retargeting.
- **Source-of-truth rule**: when a `.txt` lesson file is provided, the English content in the built site is anchored to that file's text. Definitions, example descriptions, and exercise questions are taken verbatim. The AI agent's job is to add scaffolding (intro, analogies, transitions) in English, then translate the combined English content into Egyptian Arabic for the `data-ar` layer. The Arabic is never written first and back-translated — it is always a translation of the English layer.
- **MCQ rule**: end-of-lesson exercises are always converted to 4-option multiple choice, regardless of how the original `.txt` formats them (open answer, fill-in-the-blank, etc.). The `.txt`'s questions and candidate answers become the basis for the MCQ options.
