# Code Playground — Runnable Editable Code Panels (mandatory when a section has runnable code)

Whenever the lesson content includes code that a student is meant to *execute* (Python scripts, JavaScript,
HTML/CSS demos, etc.), do NOT ship a static syntax-highlighted snippet only. Every `.code-panel` in the site
must become an **editable playground**: the student edits the code, presses **▶ Run**, and sees real output or
a clear, friendly error. This applies to ALL code panels that correspond to runnable code, regardless of
language — Python, JavaScript, HTML/CSS, or pseudocode with declared outputs.

## Non-negotiable behavior
- **Editor shows the FULL code, always.** The code editor is an auto-growing `<textarea>` — it expands to fit
  all its lines. NO internal scrollbars, NO manual resizing, NO "expand the box to see the rest". If the code
  has 12 lines, the box is tall enough for all 12. The student must never have to scroll inside the editor.
- **Output appears ONLY after pressing Run.** No always-on live preview next to the code. The output terminal
  and the error panel are `display:none` until Run is pressed.
- **Reset button** (↺) restores the original code and re-runs it.
- **Errors are friendly and readable — NOT raw compiler tracebacks.** The error panel shows, in this order:
  1. A small badge with the error type (`NameError`, `TypeError`, `ValueError`, `ZeroDivisionError`,
     `IndexError`, `AttributeError`, `SyntaxError`).
  2. A plain-language explanation in Egyptian Arabic (see the mapping table below).
  3. The line number where it happened ("المكان: السطر N").
  4. The offending source line, highlighted, with its line number in front.
  Raw traceback text like `Traceback (most recent call last): File "<web>", line 3, in <module>` is FORBIDDEN.
- The error message area should also respond to the AR/EN toggle — show the Arabic hint by default, and switch to the English equivalent when the user toggles to EN.
- English error detail strings are dropped — only the Arabic explanation is shown as the main message.

### Friendly error hint mapping (verbatim)
| Error type | Arabic hint |
|---|---|
| `NameError` | الاسم مش معرّف — لازم تعرّفه قبل ما تستخدمه (مثلاً: name = "يمني") |
| `TypeError` | نوع القيمة مش صحّ للعملية دي — مثلاً مش تقدر تجمع نص مع رقم |
| `ValueError` | القيمة مش قابلة للتحويل للنوع المطلوب |
| `ZeroDivisionError` | مينفعش تقسم على صفر |
| `IndexError` | المؤشر برّه حدود النص — الترقيم بيبدأ من صفر |
| `AttributeError` | الخاصية أو الميثود دي مش موجودة على القيمة |
| `SyntaxError` | فيه غلطة في الصياغة — راجع الأقواس أو إنهاء الجمل |

## Structure
```html
<div class="code-panel" data-inputs="grName,grCity" data-seed="name=gdName">
  <div class="code-header">greeter.py</div>
  <textarea class="py-edit" spellcheck="false">…code…</textarea>
  <div class="py-ctl">
    <button class="btn accent">▶ Run</button>
    <button class="mini-btn">↺ إعادة</button>
    <span class="hint">✏️ عدّل الكود وشغّله — شوف الناتج أو الأخطاء</span>
  </div>
  <div class="term"></div>
  <div class="py-err"></div>
</div>
```

- `data-inputs="id1,id2"` — comma-separated ids of form fields whose values feed the program's `input()`
  queue, in order. If the code calls `input()` more times than there are fields, later calls get `''`.
  **The attribute lives on the `<textarea class="py-edit">`** (see structure above). The editor wiring
  MUST read it from either the `.code-panel` OR the textarea — `panel.getAttribute('data-inputs') || ta.getAttribute('data-inputs')` — so a `data-inputs` placed on the textarea always works (a common silent-break: `input()` returns `''`, then `int('')` raises a confusing ValueError).
- `data-seed="name=gdName"` — pre-seeds variables from field values (as strings) before the code runs.
  Comma-separate multiple seeds: `data-seed="name=gdName,age=gdAge"`.
- The header shows the file name (e.g. `greeter.py`, `script.js`, `page.html`).

## CSS (embed verbatim)
```css
.py-edit, .py-edit:focus { display:block; width:100%; background:transparent; border:none; outline:none;
  padding:14px; font-family:'Consolas','Courier New',monospace; font-size:.88rem; line-height:1.6;
  color:#e0e7ff; resize:none; overflow:hidden; height:auto; min-height:56px; direction:ltr; text-align:left;
  white-space:pre; overflow-wrap:normal; box-sizing:border-box; }
.py-ctl { display:flex; gap:10px; align-items:center; padding:8px 14px;
  border-top:1px solid rgba(25,60,255,.15); }
.py-ctl .hint { color:var(--dim); font-size:.75rem; margin-left:auto; }
.term { background:#05070f; border:1px solid rgba(0,212,170,.25); border-radius:12px; padding:14px;
  font-family:Consolas,monospace; font-size:.85rem; min-height:60px; margin:10px 0; direction:ltr;
  text-align:left; display:none; }
.term .out-line { color:var(--accent); opacity:0; transform:translateY(4px);
  animation:lineIn .3s forwards; }
@keyframes lineIn { to{opacity:1; transform:translateY(0)} }
.py-err { background:#1a0a0f; border:1px solid rgba(255,71,87,.45); border-radius:12px; color:#ffb3bd;
  padding:14px 16px; margin:8px 14px; direction:ltr; text-align:left; line-height:1.6;
  animation:errIn .25s ease; display:none; }
.py-err .errtag .errbadge { background:rgba(255,71,87,.18); border:1px solid rgba(255,71,87,.4);
  border-radius:6px; padding:2px 8px; font-weight:700; font-size:.8rem; color:#ff6474;
  text-transform:uppercase; letter-spacing:.3px; }
.py-err .errmain { font-family:Consolas,monospace; font-size:.92rem; color:#fff; margin-top:8px; }
.py-err .errctx { margin-top:10px; padding-top:10px; border-top:1px solid rgba(255,71,87,.2);
  color:var(--dim); font-size:.8rem; }
.py-err .errline { background:rgba(255,71,87,.12); border-radius:6px; padding:6px 10px; margin-top:6px;
  font-family:Consolas,monospace; color:#ffd9de; font-size:.8rem; white-space:pre; overflow-x:auto; }
.py-err .errline .ln { display:inline-block; min-width:2.2em; color:#ff6470; margin-right:8px;
  user-select:none; }
```

## Language engines — pick per code panel based on the language of that panel

### Engine A — Python (mini in-browser interpreter)
For Python code, embed the mini-interpreter JS below verbatim. It supports:
- `print(...)` with `sep=` / `end=` keyword args
- `input()` (fed from `data-inputs`)
- Builtins: `int()`, `float()`, `str()`, `bool()`, `len()`, `round()`, `type()`
- String indexing `s[0]`, negative `s[-1]`, slicing `s[1:3]`, methods `.upper() .lower() .count(x)`
- f-strings: `f"Hello, {name}!"` (expressions inside `{}`)
- Operators: `+ - * / // % **`, comparisons `== != < > <= >=`, `and or not`
- `if / elif / else` blocks (indent-based, numeric indentation)
- Multiple statements per line via `;`, line continuation via `\`, `#` comments
- Errors produced: `NameError`, `TypeError`, `ValueError`, `ZeroDivisionError`, `IndexError`,
  `AttributeError`, `SyntaxError` — already formatted as `"Type: message"` strings.
- `pyRun(src, inputs, seeds)` returns `{ out: string[] | [], err: { line, msg } | null }`.

### Engine B — HTML/CSS/JS (live rendering)
For web-dev code, the output is a real rendered page, not text:
- Run sets an `<iframe>`'s `srcdoc` from the editor content — genuine rendering.
- The iframe is hidden until Run is pressed.
- For side-by-side comparisons (e.g. before/after CSS), use two iframes or a toggle.
- Output terminal is NOT used here — the iframe is the output.

#### Engine B multi-file tabbed playground (HTML + CSS + JS files together)
When a web-dev lesson splits code into separate files (`index.html`, `style.css`, `script.js`), use a
**tabbed playground**: one tab per file, all sharing one live-preview iframe. This is the CodePen-style
layout that matches how real web projects are structured.

Structure:
```html
<div class="code-panel multi-tab">
  <div class="play-tabs">
    <button class="play-tab active" data-file="0">index.html</button>
    <button class="play-tab" data-file="1">style.css</button>
    <button class="play-tab" data-file="2">script.js</button>
    <button class="btn accent play-run">▶ Run</button>
  </div>
  <textarea class="py-edit play-edit" data-src="…index.html source…" spellcheck="false">…index.html source…</textarea>
  <textarea class="py-edit play-edit hidden" data-src="…style.css source…" spellcheck="false">…style.css source…</textarea>
  <textarea class="py-edit play-edit hidden" data-src="…script.js source…" spellcheck="false">…script.js source…</textarea>
  <iframe class="play-frame"></iframe>
  <div class="py-err"></div>
</div>
```

Tab CSS (embed verbatim with the other playground CSS):
```css
.play-tabs { display:flex; gap:6px; padding:10px 14px 0; align-items:center; }
.play-tab { background:rgba(255,255,255,.04); border:1px solid transparent; border-radius:10px 10px 0 0;
  color:var(--dim); padding:7px 16px; cursor:pointer; font-family:Consolas,monospace; font-size:.8rem;
  transition:.15s; }
.play-tab.active { background:rgba(25,60,255,.25); border-color:rgba(25,60,255,.4); color:var(--text); }
.play-tab.active::before { content:""; display:inline-block; width:8px; height:8px; border-radius:50%;
  background:var(--accent); margin-right:8px; vertical-align:middle; }  /* colored dot marks the active file */
.play-edit.hidden { display:none; }
.play-frame { display:none; width:100%; height:340px; border:1px solid rgba(0,212,170,.25);
  border-radius:12px; margin:10px 0; background:#fff; }
```

Tab behavior JS (embed once):
```js
function wirePlayTabs(){
  document.querySelectorAll('.code-panel.multi-tab').forEach(function(panel){
    var edits=panel.querySelectorAll('.play-edit');
    panel.querySelectorAll('.play-tab').forEach(function(tab){
      tab.addEventListener('click',function(){
        panel.querySelectorAll('.play-tab').forEach(function(t){t.classList.remove('active');});
        tab.classList.add('active');
        edits.forEach(function(e,i){ e.classList.toggle('hidden', i!==parseInt(tab.getAttribute('data-file'))); });
      });
    });
    var frame=panel.querySelector('.play-frame'), btn=panel.querySelector('.play-run');
    if(btn) btn.addEventListener('click',function(){
      // combine all three files in DOM order into one srcdoc document
      var htmlSrc='', cssSrc='', jsSrc='';
      edits.forEach(function(e,i){ if(i===0)htmlSrc=e.value; if(i===1)cssSrc=e.value; if(i===2)jsSrc=e.value; });
      frame.srcdoc='<!DOCTYPE html><html><head><meta charset="utf-8"><style>'+cssSrc+
        '</style></head><body>'+htmlSrc+'<script>'+jsSrc+'</scr'+'ipt></body></html>';
      frame.style.display='block';
    });
  });
}
wirePlayTabs();
```

### Engine C — JavaScript (console-capture runner)
For JavaScript snippets, run with a captured console:
- Evaluate the code (new Function), redirect `console.log` / `console.error` into the output terminal.
- Each `console.log` becomes one `.out-line`. `console.error`/thrown errors render through the friendly
  error panel (badge `TypeError`/`ReferenceError`/`SyntaxError`/`RangeError` + Arabic hint from the table).

### Engine D — Pseudocode / other languages
If the "language" is pseudocode or a language with no feasible in-browser engine, use **simulated output**:
- Author the code panel with the expected output already embedded in the markup (hidden).
- Run reveals those declared output lines one at a time (small stagger) into the `.term`.
- Errors can be simulated by authoring a declared-error variant shown via the friendly error panel.

## Editor wiring JS (embed once per site — auto-grows editors, wires Run/Reset, renders friendly errors)
```js
function wireEditors(){
  function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  document.querySelectorAll('.code-panel').forEach(function(panel){
    var edit=panel.querySelector('.py-edit');
    if(!edit) return;
    if(!edit.getAttribute('data-src')) edit.setAttribute('data-src', edit.value);
    function grow(){ edit.style.height='auto'; edit.style.height=(edit.scrollHeight+2)+'px'; }
    edit.addEventListener('input',grow);
    var term=panel.querySelector('.term'), errBox=panel.querySelector('.py-err');
    var ctl=panel.querySelector('.py-ctl');
    if(ctl){
      /* Run buttons MUST carry class="btn" (accent optional). Match by '.btn', NOT
         '.btn.accent' — a Run button authored as class="btn" alone silently does
         nothing if wired with the narrower '.btn.accent' selector. */
      var run=ctl.querySelector('.btn'), reset=ctl.querySelector('.mini-btn');
      function runIt(){
        var code=edit.value;
        var inputs=[];
        (panel.getAttribute('data-inputs')||edit.getAttribute('data-inputs')||'').split(',').map(function(x){return x.trim();}).filter(Boolean).forEach(function(id){
          var el=document.getElementById(id); inputs.push(el? el.value : '');
        });
        var seeds={};
        (panel.getAttribute('data-seed')||'').split(',').map(function(x){return x.trim();}).filter(Boolean).forEach(function(pair){
          var p=pair.split('='); if(p.length===2){ var el=document.getElementById(p[1]); if(el) seeds[p[0]]=el.value; }
        });
        term.innerHTML=''; errBox.innerHTML=''; term.style.display='none'; errBox.style.display='none';
        var res = window.pyRun ? pyRun(code, inputs, seeds) : runExternal(code, inputs, seeds, panel);
        if(res && res.err){ errBox.appendChild(friendlyErr(res.err, code)); errBox.style.display='block'; }
        else if(res && res.out && res.out.length){
          res.out.forEach(function(l){ var d=document.createElement('div'); d.className='out-line'; d.textContent=l; term.appendChild(d); });
          term.style.display='block';
        }
      }
      if(run) run.addEventListener('click',runIt);
      if(reset) reset.addEventListener('click',function(){ edit.value=edit.getAttribute('data-src'); grow(); runIt(); });
    }
    grow();
  });
  function friendlyErr(er, codeSrc){
    /* WARNING: the first parameter is NAMED er, not err. Using err inside this
       function (e.g. err.line) is a ReferenceError that silently kills the whole
       error panel — the panel just never appears. Keep the name er throughout, and
       always use `er&&er.line` (guarded), never bare err.line. */
    var lineN = er&&er.line? er.line : 1;
    function lineSrc(n){ if(n<1) return ''; var l=(codeSrc||'').split('\n'); return (n-1<l.length)? l[n-1].trim() : ''; }
    var m=String(er&&er.msg?er.msg:'خطأ غير معروف'), kind='SyntaxError', detail=m;
    var km=/^([A-Za-z]+(?:Error|Exception)):\s*/.exec(m);
    if(km){ kind=km[1]; detail=m.slice(km[0].length); }
    var hints={
      NameError:'الاسم مش معرّف — لازم تعرّفه قبل ما تستخدمه (مثلاً: name = "يمني")',
      TypeError:'نوع القيمة مش صحّ للعملية دي — مثلاً مش تقدر تجمع نص مع رقم',
      ValueError:'القيمة مش قابلة للتحويل للنوع المطلوب',
      ZeroDivisionError:'مينفعش تقسم على صفر',
      IndexError:'المؤشر برّه حدود النص — الترقيم بيبدأ من صفر',
      AttributeError:'الخاصية أو الميثود دي مش موجودة على القيمة',
      SyntaxError:'فيه غلطة في الصياغة — راجع الأقواس أو إنهاء الجمل'
    };
    var frag=document.createDocumentFragment();
    var tag=document.createElement('div'); tag.className='errtag';
    var badge=document.createElement('span'); badge.className='errbadge'; badge.textContent=kind;
    tag.appendChild(badge); frag.appendChild(tag);
    var main=document.createElement('div'); main.className='errmain'; main.textContent=hints[kind]||detail||m; frag.appendChild(main);
    var ctx=document.createElement('div'); ctx.className='errctx'; ctx.textContent='المكان: السطر '+lineN; frag.appendChild(ctx);
    var src=lineSrc(lineN);
    if(src){ var lr=document.createElement('div'); lr.className='errline'; var spn=document.createElement('span'); spn.className='ln'; spn.textContent=lineN; lr.appendChild(spn); lr.appendChild(document.createTextNode(src)); frag.appendChild(lr); }
    return frag;
  }
}
wireEditors();
```

The `runExternal` function is the per-language dispatcher: for Python panels use `pyRun`, for JS use the
console-capture runner, for HTML/CSS use the `srcdoc` iframe, for pseudocode use declared outputs. The site
must include at least one engine; the Python interpreter below satisfies the Python case.

## Python mini-interpreter — embed verbatim in the site's `<script>`
```js
/* ---------- Mini Python interpreter (Python panels) ---------- */
var PNone={t:'none'};
function PNum(v,f){ return {t:f?'float':'int', v:v}; }
function PStr(v){ return {t:'str', v:String(v)}; }
function PBool(v){ return {t:'bool', v:!!v}; }
function PType(n){ return {t:'type', name:n}; }
function isNum(x){ return x.t==='int'||x.t==='float'; }
function pstr(x){
  if(x.t==='int') return String(x.v);
  if(x.t==='float'){ return Number.isInteger(x.v)? x.v+'.0' : String(x.v); }
  if(x.t==='str') return x.v;
  if(x.t==='bool') return x.v?'True':'False';
  if(x.t==='none') return 'None';
  if(x.t==='type') return "<class '"+x.name+"'>";
  return '';
}
function ptype(x){ return x.t==='int'?'int':x.t==='float'?'float':x.t==='str'?'str':x.t==='bool'?'bool':x.t==='none'?'NoneType':'object'; }
function truthy(x){ if(x.t==='bool')return x.v; if(isNum(x))return x.v!==0; if(x.t==='str')return x.v.length>0; return false; }
function pErr(msg){ var e=new Error(msg); e.msg=msg; return e; }

function pyEscape(ch){ if(ch==='n')return '\n'; if(ch==='t')return '\t'; if(ch==='\\')return '\\'; return ch; }
function pyTokenize(code){
  var toks=[], i=0, n=code.length;
  while(i<n){
    var c=code[i];
    if(/\s/.test(c)){ i++; continue; }
    if(/[0-9]/.test(c) || (c==='.'&&/[0-9]/.test(code[i+1]||''))){
      var m=/^(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?/.exec(code.slice(i));
      var num=parseFloat(m[0]);
      toks.push({k:'num', v:num, f:/[.eE]/.test(m[0])}); i+=m[0].length; continue;
    }
    if(c==='f'&&(code[i+1]==='"'||code[i+1]==="'")){
      var q2=code[i+1], k=i+2, s2='';
      while(k<n&&code[k]!==q2){ if(code[k]==='\\'&&k+1<n){ s2+=pyEscape(code[k+1]); k+=2; } else { s2+=code[k]; k++; } }
      toks.push({k:'fstr', v:s2}); i=k+1; continue;
    }
    if(c==='"'||c==="'"){
      var q=c, j=i+1, s='';
      while(j<n&&code[j]!==q){ if(code[j]==='\\'&&j+1<n){ s+=pyEscape(code[j+1]); j+=2; } else { s+=code[j]; j++; } }
      toks.push({k:'str', v:s}); i=j+1; continue;
    }
    if(/[A-Za-z_]/.test(c)){
      var m2=/^[A-Za-z_][A-Za-z0-9_]*/.exec(code.slice(i));
      toks.push({k:'id', v:m2[0]}); i+=m2[0].length; continue;
    }
    var two=code.slice(i,i+2);
    if(two==='//'||two==='**'||two==='>='||two==='<='||two==='=='){ toks.push({k:'op',v:two}); i+=2; continue; }
    if(c==='!'){ toks.push({k:'op',v:'!='}); i+=2; continue; }
    if('+-*/%()[].,:<>='.indexOf(c)>=0){ toks.push({k:'op',v:c}); i++; continue; }
    toks.push({k:'op',v:c}); i++;
  }
  toks.push({k:'eof',v:''}); return toks;
}

function pyParse(code, env, out){
  var toks=pyTokenize(code), i=0;
  function peek(){ return toks[i]; }
  function next(){ return toks[i++]; }
  function binPrec(t){
    if(t.k==='id'){ if(t.v==='or')return 1; if(t.v==='and')return 2; return null; }
    if(t.k==='op'){ var m={'==':4,'!=':4,'<':4,'>':4,'<=':4,'>=':4,'+':5,'-':5,'*':6,'/':6,'//':6,'%':6,'**':7}; return m[t.v]!==undefined? m[t.v]:null; }
    return null;
  }
  function parseFStr(raw){
    var s='', depth=0, sub='';
    for(var j=0;j<raw.length;j++){
      var c=raw[j];
      if(c==='{'&&depth===0){ depth=1; sub=''; continue; }
      if(depth>0){
        if(c==='{')depth++;
        else if(c==='}'){ depth--; if(depth===0){ var v=pyParse(sub,env,out).parseAll(); s+=pstr(v); continue; } }
        sub+=c; continue;
      }
      s+=c;
    }
    return PStr(s);
  }
  function call(fn,args){
    if(fn.k==='fn'){
      var name=fn.name;
      if(name==='print'){
        var sep=' ', end='\n', vals=[];
        for(var a=0;a<args.length;a++){
          if(args[a].k==='kw'){ if(args[a].n==='sep')sep=pstr(args[a].v); else if(args[a].n==='end')end=pstr(args[a].v); }
          else vals.push(args[a]);
        }
        out.buf += vals.map(pstr).join(sep)+end; return PNone;
      }
      if(name==='input'){ var iv=out.inQ.length? out.inQ.shift() : ''; return PStr(iv); }
      if(name==='int'){
        var x=args[0];
        if(x.t==='int')return x;
        if(x.t==='float')return PNum(Math.trunc(x.v),false);
        if(x.t==='bool')return PNum(x.v?1:0,false);
        if(x.t==='str'){ var s=x.v.trim(); if(/^[+-]?\d+$/.test(s))return PNum(parseInt(s,10),false); if(/^[+-]?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?$/.test(s))return PNum(parseInt(parseFloat(s),10),false); throw pErr("ValueError: invalid literal for int() with base 10: '"+x.v+"'"); }
        throw pErr("TypeError: int() argument must be a string or a number");
      }
      if(name==='float'){
        var y=args[0];
        if(y.t==='float')return y;
        if(y.t==='int')return PNum(y.v,true);
        if(y.t==='bool')return PNum(y.v?1:0,true);
        if(y.t==='str'){ var s2=y.v.trim(); if(/^[+-]?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?$/.test(s2))return PNum(parseFloat(s2),true); throw pErr("ValueError: could not convert string to float: '"+y.v+"'"); }
        throw pErr("TypeError: float() argument must be a string or a number");
      }
      if(name==='str') return PStr(pstr(args[0]));
      if(name==='bool') return PBool(truthy(args[0]));
      if(name==='len'){ if(args[0].t==='str') return PNum(args[0].v.length,false); throw pErr("TypeError: object of type '"+ptype(args[0])+"' has no len()"); }
      if(name==='round'){ var rv=args[0].v, nd=args.length>1? args[1].v : null; var r=nd===null? Math.round(rv) : Math.round(rv*Math.pow(10,nd))/Math.pow(10,nd); return PNum(r, nd!==null); }
      if(name==='type') return PType(ptype(args[0]));
      throw pErr("NameError: name '"+name+"' is not defined");
    }
    throw pErr("TypeError: '"+ptype(fn)+"' object is not callable");
  }
  function normIdx(v,len){ var i=v.v; return i<0? i+len : i; }
  function index(x,a,b,hasColon){
    if(x.t!=='str') throw pErr("TypeError: '"+ptype(x)+"' object is not subscriptable");
    var s=x.v;
    if(hasColon){
      var st=a===null?0:normIdx(a,s.length), en=b===null?s.length:normIdx(b,s.length);
      st=Math.max(0,Math.min(st,s.length)); en=Math.max(0,Math.min(en,s.length));
      return PStr(s.slice(st,en));
    }
    var idx=normIdx(a,s.length);
    if(idx<0||idx>=s.length) throw pErr("IndexError: string index out of range");
    return PStr(s[idx]);
  }
  function method(x,m,args){
    if(x.t!=='str') throw pErr("AttributeError: '"+ptype(x)+"' object has no attribute '"+m+"'");
    if(m==='upper') return PStr(x.v.toUpperCase());
    if(m==='lower') return PStr(x.v.toLowerCase());
    if(m==='count'){ var sub=args.length? pstr(args[0]) : ''; return PNum(x.v.split(sub).length-1,false); }
    throw pErr("AttributeError: 'str' object has no attribute '"+m+"'");
  }
  function parsePrimary(){
    var t=next();
    if(t.k==='num') return PNum(t.v,t.f);
    if(t.k==='str') return PStr(t.v);
    if(t.k==='fstr') return parseFStr(t.v);
    if(t.k==='id'){
      if(t.v==='True')return PBool(true);
      if(t.v==='False')return PBool(false);
      if(t.v==='None')return PNone;
      if(t.v in env) return env[t.v];
      var nt=peek();
      if(nt.k==='op'&&nt.v==='(') return {k:'fn', name:t.v};
      throw pErr("NameError: name '"+t.v+"' is not defined");
    }
    if(t.k==='op'&&t.v==='('){ var e=parseExpr2(0); if(peek().v===')')next(); return e; }
    var tk=(t.k==='op'?t.v:t.v);
    throw pErr("SyntaxError: unexpected token"+(tk?(" '"+tk+"'"):" in the expression"));
  }
  function parsePostfix(x){
    for(;;){
      var t=peek();
      if(t.k==='op'&&t.v==='('){
        next(); var args=[];
        while(peek().v!==')'){
          if(peek().k==='id'&&toks[i+1]&&toks[i+1].k==='op'&&toks[i+1].v==='='){ var kn=next().v; next(); args.push({k:'kw', n:kn, v:parseExpr2(0)}); }
          else args.push(parseExpr2(0));
          if(peek().v===',')next();
        }
        if(peek().v===')')next();
        return call(x,args);
      }
      if(t.k==='op'&&t.v==='['){
        next(); var a=null,b=null,hasColon=false;
        if(peek().v===':'){ next(); hasColon=true; if(peek().v!==']')b=parseExpr2(0); }
        else { a=parseExpr2(0); if(peek().v===':'){ next(); hasColon=true; if(peek().v!==']')b=parseExpr2(0); } }
        if(peek().v===']')next();
        return index(x,a,b,hasColon);
      }
      if(t.k==='op'&&t.v==='.'){
        next(); var m=next();
        var args2=[];
        if(peek().v==='('){
          next();
          while(peek().v!==')'){
            if(peek().k==='id'&&toks[i+1]&&toks[i+1].k==='op'&&toks[i+1].v==='='){ var kn2=next().v; next(); args2.push({k:'kw', n:kn2, v:parseExpr2(0)}); }
            else args2.push(parseExpr2(0));
            if(peek().v===',')next();
          }
          if(peek().v===')')next();
        }
        return parsePostfix(method(x,m.v,args2));
      }
      break;
    }
    return x;
  }
  function parsePrefix(){
    var t=peek();
    if(t.k==='id'&&t.v==='not'){ next(); return PBool(!truthy(parseExpr2(3))); }
    if(t.k==='op'&&t.v==='-'){
      next(); var v=parseExpr2(7);
      if(isNum(v))return PNum(-v.v, v.t==='float');
      if(v.t==='bool')return PNum(v.v?1:0,false);
      throw pErr("TypeError: bad operand type for unary -: '"+ptype(v)+"'");
    }
    return parsePostfix(parsePrimary());
  }
  function binOp(t,a,b){
    var op=t.k==='id'? t.v : t.v;
    if(op==='and') return truthy(a)? b : a;
    if(op==='or') return truthy(a)? a : b;
    if(op==='=='||op==='!='){
      var eq=false;
      if(isNum(a)&&isNum(b))eq=a.v===b.v;
      else if(a.t==='str'&&b.t==='str')eq=a.v===b.v;
      else if(a.t==='bool'&&b.t==='bool')eq=a.v===b.v;
      else if(a.t==='none'&&b.t==='none')eq=true;
      return PBool(op==='=='?eq:!eq);
    }
    if(op==='<'||op==='>'||op==='<='||op==='>='){ var r=op==='<'?a.v<b.v:op==='>'?a.v>b.v:op==='<='?a.v<=b.v:a.v>=b.v; return PBool(r); }
    if(op==='+'){
      if(a.t==='str'&&b.t==='str')return PStr(a.v+b.v);
      if(a.t==='str'||b.t==='str') throw pErr("TypeError: can only concatenate str (not '"+ptype(isNum(a)?b:a)+"') to str");
      return PNum(a.v+b.v, a.t==='float'||b.t==='float');
    }
    if(op==='*'&&a.t==='str'&&b.t==='int') return PStr(a.v.repeat(b.v));
    if(op==='*'&&a.t==='int'&&b.t==='str') return PStr(b.v.repeat(a.v));
    if(!isNum(a)||!isNum(b)) throw pErr("TypeError: unsupported operand type(s) for "+op+": '"+ptype(a)+"' and '"+ptype(b)+"'");
    var x=a.v,y=b.v, fl=a.t==='float'||b.t==='float';
    if(op==='-')return PNum(x-y,fl);
    if(op==='*')return PNum(x*y,fl);
    if(op==='/'){ if(y===0)throw pErr("ZeroDivisionError: division by zero"); return PNum(x/y,true); }
    if(op==='//'){ if(y===0)throw pErr("ZeroDivisionError: integer division or modulo by zero"); return PNum(Math.floor(x/y),fl); }
    if(op==='%'){ if(y===0)throw pErr("ZeroDivisionError: integer division or modulo by zero"); return PNum(x%y,fl); }
    if(op==='**')return PNum(Math.pow(x,y),fl);
    throw pErr("SyntaxError: unknown operator "+op);
  }
  function parseExpr2(minPrec){
    var left=parsePrefix();
    for(;;){
      var t=peek();
      var prec=binPrec(t);
      if(prec===null||prec<minPrec)break;
      next();
      var right=parseExpr2(t.k==='id'? prec+1 : (t.v==='**'? prec : prec+1));
      left=binOp(t,left,right);
    }
    return left;
  }
  function parseAll(){ var v=parseExpr2(0); if(peek().k!=='eof') throw pErr("SyntaxError: trailing tokens in expression"); return v; }
  return { parseAll: parseAll };
}

function pyStripComment(line){ var inStr=null; for(var i=0;i<line.length;i++){ var c=line[i]; if(inStr){ if(c===inStr)inStr=null; continue; } if(c==='"'||c==="'"){ inStr=c; continue; } if(c==='#')return line.slice(0,i); } return line; }
function pyTopColon(s){ var depth=0,inStr=null; for(var i=0;i<s.length;i++){ var c=s[i]; if(inStr){ if(c===inStr)inStr=null; continue; } if(c==='"'||c==="'"){ inStr=c; continue; } if(c==='('||c==='[')depth++; if(c===')'||c===']')depth--; if(c===':'&&depth===0)return i; } return -1; }
function pyTopEq(s){ var depth=0,inStr=null; for(var i=0;i<s.length;i++){ var c=s[i]; if(inStr){ if(c===inStr)inStr=null; continue; } if(c==='"'||c==="'"){ inStr=c; continue; } if(c==='('||c==='[')depth++; if(c===')'||c===']')depth--; if(c==='='&&depth===0){ var pr=s[i-1],nx=s[i+1]; if(pr==='='||pr==='>'||pr==='<'||pr==='!'||nx==='=')continue; return i; } } return -1; }
function pySplitStmts(s){ var out=[],depth=0,inStr=null,cur=''; for(var i=0;i<s.length;i++){ var c=s[i]; if(inStr){ cur+=c; if(c===inStr)inStr=null; continue; } if(c==='"'||c==="'"){ inStr=c; cur+=c; continue; } if(c==='('||c==='['){ depth++; cur+=c; continue; } if(c===')'||c===']'){ depth--; cur+=c; continue; } if(c===';'&&depth===0){ out.push(cur); cur=''; continue; } cur+=c; } if(cur.trim()!=='')out.push(cur); return out; }

function pyRun(src, inputs, seeds){
  var env={}, curLine=0;
  for(var s in seeds) env[s]=PStr(seeds[s]);
  var out={ buf:'', inQ:(inputs||[]).slice() };
  try {
    var raw=src.split('\n'), lines=[], pending='';
    for(var r=0;r<raw.length;r++){
      var line=raw[r].replace(/\r$/,'');
      var stripped=pyStripComment(line);
      var indentMatch=/^[ \t]*/.exec(line)[0];
      var indent=indentMatch.replace(/\t/g,'    ').length;
      if(/\\\s*$/.test(stripped)){ pending += stripped.replace(/\\\s*$/,'').replace(/^[ \t]*/,'')+' '; continue; }
      var code=(pending+stripped).trim(); pending='';
      if(code==='')continue;
      lines.push({indent:indent, code:code, line:r+1});
    }
    if(pending.trim()!=='') lines.push({indent:0, code:pending.trim(), line:raw.length});
    function runStmts(arr,start){
      var i=start;
      while(i<arr.length){
        var ln=arr[i];
        curLine=ln.line;
        if(/^(if|elif|else)\b/.test(ln.code)){
          var bi=ln.indent, clauses=[];
          while(i<arr.length){
            var cur=arr[i];
            var cm=/^(if|elif|else)\b/.exec(cur.code);
            if(!cm||cur.indent!==bi)break;
            var colonIdx=pyTopColon(cur.code);
            var condSrc = cm[1]==='else'? '' : cur.code.slice(cm[0].length,colonIdx).trim();
            var tail = colonIdx>=0? cur.code.slice(colonIdx+1).trim() : '';
            var body=[];
            if(tail) body.push({indent:bi+1, code:tail, line:cur.line});
            var j=i+1;
            while(j<arr.length&&arr[j].indent>bi){ body.push(arr[j]); j++; }
            clauses.push({kw:cm[1], cond:condSrc, body:body});
            i=j;
            var nl=arr[i];
            if(!(nl&&/^(elif|else)\b/.test(nl.code)&&nl.indent===bi))break;
          }
          var matched=false;
          for(var c=0;c<clauses.length;c++){
            var cl=clauses[c];
            var runIt;
            if(cl.kw==='else') runIt=!matched;
            else { runIt=!matched && truthy(pyParse(cl.cond,env,out).parseAll()); if(runIt) matched=true; }
            if(runIt) runStmts(cl.body,0);
          }
        } else {
          pySplitStmts(ln.code).forEach(function(st){
            var eq=pyTopEq(st);
            if(eq>0){
              var name=st.slice(0,eq).trim();
              var rhs=st.slice(eq+1).trim();
              if(/^[A-Za-z_][A-Za-z0-9_]*$/.test(name)){ env[name]=pyParse(rhs,env,out).parseAll(); return; }
            }
            pyParse(st,env,out).parseAll();
          });
          i++;
        }
      }
      return i;
    }
    runStmts(lines,0);
    var text=out.buf;
    if(text.slice(-1)==='\n')text=text.slice(0,-1);
    return { out: text===''?[]:text.split('\n'), err:null };
  } catch(e){
    var msg=e&&e.msg? e.msg : String(e&&e.message||e);
    return { out:[], err:{ line:curLine, msg:msg } };
  }
}
window.pyRun=pyRun;
/* ---------- End Mini Python interpreter ---------- */
```

## Cross-check with existing reference
- The **Live Code Preview** pattern in `design-system.md` is Engine B above (HTML/CSS/JS). Keep its
  iframe-based behavior and editable-code requirement; the only addition here is the "hidden until Run"
  rule and the friendly-error panel for JS/parse errors.
- The code panels must still follow the mandatory LTR rules from `design-system.md` (`dir="ltr"`,
  `unicode-bidi: isolate`, monospace).
