# Design System — CS Interactive Explainer (EGYPT-ICT-HUB Edition)

Embed all of this into the master prompt as strict requirements, not suggestions.

## Audience & purpose
Students aged 12–17. The site is built **for the teacher (Bilal) to present from**, standing in front of a class with a laptop + projector. It is NOT a student self-study tool. One single experience — do not build a student/teacher mode toggle. Quiz answers and any "detail" content are hidden by default and revealed on click by the teacher during the lesson.

## Layout & platform
- Single self-contained HTML file: all CSS, JS, SVG, and the logo (base64) live inside the one file. No external files, no CDN dependencies for anything critical (Google Fonts link is fine).
- Desktop-first (laptop screen size and up). Mobile is not a priority — don't spend effort on a mobile layout, but don't break outright either.
- Sticky top navigation bar listing all section titles, clickable to jump directly to a section. Not a sidebar.
- Structure: intro section ("هنتعلم ايه النهارده" — what we'll learn today) → one block per confirmed section → closing summary section.
- Section-internal layout (text vs. SVG placement — side by side or stacked) is left to the AI agent's judgment per section, whichever fits that section's content best.

## Color & type — Dark Animated Theme
This is a **dark theme** with animated backgrounds. Do NOT use light/white backgrounds.

### CSS Variables (mandatory)
```css
:root {
  --primary: #193cff;
  --accent: #00d4aa;
  --bg: #0a0e27;
  --card: #111638;
  --card-hover: #1a2050;
  --text: #fff;
  --dim: #8892b0;
  --success: #00ff88;
  --danger: #ff4757;
  --warn: #ffd700;
}
```

### Per-section accent colors
Each section gets its own accent color from this palette, used on that section's number badge, top border, and icon:
- Cyan `#06B6D4`, Amber `#F59E0B`, Violet `#8B5CF6`, Emerald `#10B981`, Pink `#EC4899`, Red `#EF4444`, Blue `#193cff`

### Background
- Body background: `var(--bg)` (`#0a0e27` — dark navy).
- Animated radial gradient overlay: two soft radial gradients (primary at 30% 50%, accent at 70% 80%) with a slow 20s ease-in-out loop that gently shifts position. applied via `position: fixed` behind everything.
- Floating particles: 30 small dots (`4px`, `var(--primary)`, `opacity: 0.3`) floating upward on a 15s linear loop, staggered delays. Purely decorative, `pointer-events: none`.

### Cards & containers
- `background: var(--card)` (`#111638`)
- `border: 1px solid rgba(255,255,255,0.05)`
- `border-radius: 24px` on large containers, `16px` on smaller cards.
- Hover: `background: var(--card-hover)` + `translateY(-5px)` + `border-color: rgba(25,60,255,0.3)`.
- Diagram containers get a top gradient bar: `height: 3px; background: linear-gradient(90deg, var(--primary), var(--accent))`.

### Navigation
- Fixed top bar, `background: rgba(10,14,39,0.95)` with `backdrop-filter: blur(20px)`.
- `border-bottom: 1px solid rgba(25,60,255,0.3)`.
- Starts hidden (`translateY(-100%)`), appears after scrolling 100px.
- Nav links: pill-shaped (`border-radius: 25px`), `color: var(--dim)`, hover/active: `color: var(--text); background: rgba(25,60,255,0.2); border-color: var(--primary)`.
- **Nav scrolls horizontally, never wraps**: the links bar uses `overflow-x: auto` with hidden scrollbars (`scrollbar-width: none;` + `::-webkit-scrollbar{display:none}`) and `flex-wrap: nowrap`; each link is `flex-shrink: 0`. Many sections must not cause a second row.

### Typography
- Arabic font: Cairo (from Google Fonts), weights 400/600/700/900.
- Body text: `color: var(--dim)` (`#8892b0`).
- Headings: `color: var(--text)`, `font-weight: 900`.
- Hero title: `clamp(36px, 8vw, 80px)` with gradient text span (`linear-gradient(135deg, var(--primary), var(--accent))`).

## Motion — mandatory, this is the part earlier attempts got too static
The site must feel alive, not like a static printed page. Two concrete mechanisms, both required:

**1. Landing hero section (first viewport, before any lesson content)**
A full first-screen hero: profile photo (optional but recommended for Bilal's personal brand), small pill badge, big title with the key term highlighted via a gradient-text span, a one-line subtitle, and a "start" button that scrolls down to the first section. Every hero element enters with a staggered fade-up on page load (opacity 0→1 + translateY(40px→0), ~0.8s ease-out, each element delayed ~0.2s after the previous — badge, then title, then subtitle, then button). Add 2–3 large soft blurred circles floating gently in the hero background (slow up/down loop, ~6s, different delays per circle) purely for visual life — low opacity, decorative only, never on top of text.

### Hero profile photo
- The hero may include a profile photo of the presenter (Bilal) on one side, with the title/badge/button on the other.
- The photo is displayed inside `.hero-photo` with a soft glowing frame behind it (`.hero-photo::before` pseudo-element with `inset: -10px`, `border-radius`, gradient background, `filter: blur`, and a gentle floating animation).
- Photo display size: `clamp(230px, 29vw, 370px)` wide, `border-radius: 30px`, with a subtle border and shadow.
- The photo image should be a background-removed PNG or JPEG with transparency support, placed in the project's `assets/` folder and referenced relatively.
- The photo container must not overflow or break the hero layout on smaller desktop screens.

**2. Scroll-triggered reveal on every content block — not just once per section**
Wrap *each individual piece* of content (section header, each concept card, each example box, each recap box, each diagram) in its own reveal element — not one reveal wrapper around a whole giant section. This is what makes content feel like it's being "read line by line with you" instead of dumped as one wall of text.
- Base state: `opacity: 0; transform: translateY(30px);` with `transition: all 0.6s cubic-bezier(0.4, 0, 0.2, 1)`
- Revealed state (class `visible` added by JS): `opacity: 1; transform: translateY(0)`
- Trigger mechanism: a single `IntersectionObserver` (threshold ~0.05) observing all `.section-inner` elements; when an element intersects, add its `visible` class. Also a fallback `checkVisibility()` on scroll for elements already in view.
- Keep body text broken into these small revealing chunks (a short paragraph, then a diagram, then the next short paragraph) rather than one long paragraph followed by one diagram.

**3. Small looping decorative animations, used purposefully (not everywhere)**
- Wires/current flow in circuit-style diagrams: animate `stroke-dashoffset` on a dashed stroke (`stroke-dasharray`) to suggest current flowing along a wire — great fit for circuit/gate diagrams.
- A pulsing scale (`transform: scale(1) → scale(1.05) → scale(1)`, ~2s loop) on an element to indicate "this is currently active/on".
- A glow animation on section number badges: `box-shadow: 0 0 20px rgba(25,60,255,0.3) → 0 0 40px rgba(25,60,255,0.6)`, 3s infinite loop.
- A blink (opacity 1↔0.25 loop) for something like a status LED.
- Use these for things that are genuinely "live" or "on" in a diagram — not as generic decoration everywhere.
- Corner radius: soft/rounded on large elements — cards, buttons, containers, section frames. Sharper/more geometric only inside technical diagram details.
- Illustration style: clean geometric primitives (rect/line/arrow) for technical content, with glow effects (`filter: drop-shadow`) on active elements.

## Emoji policy — minimal in text, activity-only for animations
Keep emojis out of body paragraph text and formal explanation prose. However, emojis ARE permitted in:
- Section badges and labels
- Hero and heading decorations
- Activity/simulation elements where they act as image-like visual props (e.g. 🚶 a person walking, 📦 a packet, 🧊/🔥 a tile)

For activity emojis used as animated icons, prefer CSS keyframe classes:
- Smooth, lightweight, educational — never distracting.
- Loop naturally. Avoid excessive bouncing or exaggerated effects.
- Use CSS keyframe classes: `.emoji-pulse` (scale), `.emoji-shake` (horizontal shake), `.emoji-walk` (vertical bounce), `.emoji-float` (float + rotation), `.emoji-glow` (drop-shadow pulse).

Keep the small set of functional feedback marks that have no good text-only replacement: ✅ correct, ❌ wrong, ⚠️ warning/error box, directional arrows (← →) on navigation/step buttons, 💡 hint in a fix suggestion. Everything else must be removed from formal prose.

## Teaching philosophy
The website is projected by a teacher in front of students. Every visual element should:
- Attract attention immediately.
- Explain the concept visually before students read the text.
- Make the lesson feel alive.
- Reduce the amount of text needed.

Whenever possible, **show an action instead of describing it**. Good examples: 🚶 walks toward a door, 🚗 enters a garage, 📧 travels between computers, 🔒 closes automatically, 🛡️ blocks an incoming attack, 💡 lights up when an idea is introduced.

The goal is that every section feels interactive, colorful, expressive, and memorable without becoming childish.

## Language rules
- Page-level: `dir="rtl"` on `<html>`.
- UI microcopy (buttons, nav labels, e.g. "التالي", "جرّب", "إجابة") — Modern Standard Arabic (فصحى).
- Explanation body text — Egyptian Arabic dialect (مصري), with English CS terms preserved in English, not translated/transliterated.
- Body text per section is a full, detailed, self-contained explanation (not slide-style minimal bullets) — a student reading it alone should be able to understand the concept, even though it's primarily used by the teacher narrating live.
- **Bidi rule (mandatory)**: prepend "الـ" before any English term that starts a line, a heading, a list item, or a table cell.
- Wrap every embedded English term in a `<span dir="ltr">` for correct bidi isolation. Do not rely on plain text bidi resolution.
- No hover/click tooltips for technical terms — the body explanation must be sufficient on its own.

## Bilingual toggle (AR/EN) — mandatory on every site
Every interactive explainer site must include a working Arabic/English toggle so the teacher can switch the entire page language during presentation.

### Toggle button (navbar)
- Place a button with class `lang-toggle` and id `langToggle` inside the top navigation bar, after the nav links.
- Initial state: `data-current="ar"` and the button text shows `EN` (because the default language is Arabic, so the button label is the *other* language).
- CSS:
  ```css
  .lang-toggle {
    flex-shrink: 0;
    padding: 8px 16px;
    border-radius: 50px;
    border: 1px solid rgba(255,255,255,.2);
    background: transparent;
    color: var(--text);
    font-family: inherit;
    font-weight: 700;
    font-size: 14px;
    cursor: pointer;
    transition: all .3s ease;
  }
  .lang-toggle:hover {
    border-color: var(--accent);
    background: rgba(0,212,170,.1);
  }
  ```
- The nav links bar must use `flex: 1` so the toggle stays pinned to the right (in RTL) or left edge.

### Translatable elements
- Every piece of visible text that is not a code keyword, filename, or proper noun must carry both `data-ar` and `data-en` attributes.
- The *current* language is shown as the element's inner text; the *other* language lives in the attribute.
- Values are plain text only — do NOT wrap translatable strings in extra `<span>` tags inside the attribute value. Keep HTML markup (like `<span dir="ltr">Python</span>`) only in the visible inner text, not inside `data-ar`/`data-en`.

### JavaScript
- `setLang(lang)` toggles `dir` and `lang` on the `<html>` element, updates every `[data-ar][data-en]` element's inner text to match, dispatches a `langChange` event on `document`, and persists the choice with `localStorage.setItem('langPreference', lang)`.
- All dynamic content (operator names, error messages, exercise scores, simulation labels) must listen for `langChange` and re-render in the correct language.
- For operator tables, provide a `refreshOperators(lang)` helper that re-paints the operator chips and the active operation detail when the language flips.
- On page load, read `localStorage.getItem('langPreference')` and call `setLang()` with the saved value (defaulting to `'ar'`).

## Interaction
- Two trigger types combine: elements animate/reveal as they scroll into view, AND clicking reveals further detail (used by the teacher live).
- Interaction complexity target: medium — small step-by-step simulations per concept, not single toggle-only effects and not full multi-screen simulations.
- Every section's interactive animation has a **replay button** to reset it back to the start (needed when teaching the same lesson to multiple classes in one day).
- **Keyboard navigation**: left/right arrow keys move between steps/sections, for hands-free presenting.
- Legend/key box next to any technical diagram (array, tree, circuit, etc.) explaining what each color/shape represents.

## Quiz (in-section recall checks)
- Number of questions per section depends on that section's complexity — can be more than one if warranted.
- Immediate feedback on selection: color (green/red) plus a short sentence explaining *why* a wrong answer is wrong.
- A skip button is always available.
- This per-question color-feedback pattern is reserved for short in-section recall checks only.

## End-of-lesson exercises (MCQ + self-work-then-reveal)
When exercises appear at the end of the lesson (after all sections, typically titled "Exercise", "Warm Up", "Try", "Answer the following questions", or their Arabic equivalents), convert them to **multiple-choice format**:

### MCQ structure
- Each question gets a `<div class="q">` with a numbered label (`<span class="q-num">N</span>`) and the question text in both `data-ar` and `data-en`.
- Provide exactly **4 options** labeled A, B, C, D inside `<div class="ex-options">`. Each option is a `<div class="ex-opt">`.
- The correct answer gets `data-ok="1"` on its `<div class="ex-opt">`. This is used by the reveal JS to highlight it green when answers are shown.
- If the original `.txt` has fewer than 4 candidate answers, the AI agent must generate plausible distractors (wrong options) that reflect common student mistakes — do NOT leave fewer than 4 options.
- If the original `.txt` has more than 4 candidates (e.g. 5 or 6), pick the 4 most instructive ones. Do not exceed 4 options.

### Answer reveal
- All answers are hidden by default (`display:none` on `.ex-answer`).
- One button at the end of the whole exercise block toggles all answers visible.
- Each `.ex-answer` carries `data-ar` and `data-en` with the explanation text.
- The answer explanation should state the correct letter and explain *why* it is correct, in Egyptian Arabic for `data-ar` and clear English for `data-en`.
- Do NOT use per-question immediate green/red color feedback for end-of-lesson exercises. The self-work-then-reveal pattern is the only pattern allowed here.

### In-section quizzes (distinct from end-of-lesson exercises)
- Short recall checks embedded within a section. Use the per-question immediate color-feedback pattern (green/red + explanation + skip button).
- These are interactive and guide the student question by question.

## Code snippets
- When the lesson includes code examples, render them with syntax highlighting (e.g. highlight.js via CDN, or an inline minimal highlighter — agent's choice as long as it doesn't break the single-file requirement if CDN is unavailable offline; prefer bundling a minimal highlighter inline over a hard CDN dependency).
- **Code panels MUST be LTR**: the whole page is `dir="rtl"`, so code panels inherit RTL and look broken. Every code panel wrapper must have `dir="ltr"`, and the CSS must include:
  ```css
  .code-panel, .code-panel .code-body, .code-panel .code-header {
    direction: ltr;
    text-align: left;
    unicode-bidi: isolate;
  }
  ```

### Runnable code playground (edit → run → output) — MANDATORY for runnable code
Whenever a code example is something a student is meant to execute (Python, JavaScript, HTML/CSS demo,
pseudocode with declared outputs), it must not be a static snippet. It must be an **editable playground**:
- The code is an auto-growing `<textarea class="py-edit">` that always shows ALL of its lines — no internal
  scrollbars, no manual resizing, never any "expand the box to see the rest".
- A control bar (**▶ Run** + **↺ إعادة** + hint) and a hidden output terminal (`.term`).
- Output appears ONLY after pressing **▶ Run** — never an always-on live preview beside the code.
- **Friendly error panel** (`.py-err`): error-type badge + plain-language Arabic explanation + line number +
  the offending source line. Raw compiler tracebacks are FORBIDDEN.
- Language engines: Python = built-in mini interpreter (self-contained JS in the site); HTML/CSS/JS = real
  live `<iframe>` rendering via `srcdoc`; JavaScript = console-capture runner; other/pseudocode = declared
  (simulated) output revealed on Run.
- Inputs from the teacher/students feed the run through `data-inputs` (comma-separated field ids → `input()`
  queue) and `data-seed` (pre-seeded variables from field values).

**Full reference (structure, CSS, wiring JS, and the complete Python mini-interpreter, embed verbatim):
`references/code-playground.md`. The master prompt MUST instruct the coding agent to embed that
interpreter and the editor wiring, and to apply this pattern to every runnable code panel.**

## Activity grid layout
- Used when a section has a simulation/demo alongside code or explanation. CSS:
  ```css
  .activity-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 24px;
  }
  .activity-grid .demo-panel {
    display: flex;
    flex-direction: column;
    gap: 16px;
    padding: 20px;
    background: rgba(255,255,255,.03);
    border-radius: 16px;
    border: 1px solid rgba(255,255,255,.06);
  }
  ```
- On mobile (`max-width: 860px`), stack to single column: demo-panel first (order: 1), code-panel second (order: 2).
- When there's no code panel (animation only), use `grid-template-columns: 1fr` instead.

## Form controls (inputs + dropdowns) must be dark — never white
Problems happen when the OS renders the expanded `<select>` dropdown as a white popup, or the input background ends up light. Mandatory CSS for ALL `.demo-panel` inputs and selects (and any form control anywhere):
```css
.activity-grid .demo-panel input, .activity-grid .demo-panel select {
  width:100%; background:#1a2050; border:1px solid rgba(255,255,255,.15);
  color:var(--text); border-radius:8px; padding:8px 12px; font-family:inherit;
  color-scheme:dark;              /* makes the native select popup render dark */
}
.activity-grid .demo-panel select option { background:#111638; color:var(--text); }
.activity-grid .demo-panel input:focus, .activity-grid .demo-panel select:focus { outline:none; border-color:var(--primary); }
```
`color-scheme: dark` is the key line — without it, browsers (Chrome/Edge) paint the expanded dropdown list white. Apply the same pattern wherever a select/input appears (e.g. an if-gate status selector).

## Equal-width widget grids — always divide into full even rows
Widget clusters (operator chips, comparison chips, factory cells, etc.) must NEVER leave a lone orphan widget hanging at the end of a row. Do not use `flex-wrap: wrap` for these. Use a fixed CSS grid whose column count divides the widget count evenly, with explicit responsive fallbacks:
```css
.op-gallery { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:14px; }   /* e.g. 8 widgets -> 4+4 */
.op-gallery.cols-3 { grid-template-columns:repeat(3,minmax(0,1fr)); }                   /* 6 widgets -> 3+3 */
@media(max-width:960px){ .op-gallery, .op-gallery.cols-3 { grid-template-columns:repeat(2,minmax(0,1fr)); } }
@media(max-width:560px){ .op-gallery, .op-gallery.cols-3 { grid-template-columns:1fr; } }
```
Pick the column count per cluster so no row is left with a single chip: even counts split exactly (6→3+3, 8→4+4), odd counts use `<n>+<n-1>` rows (7→4+3). Never ship a cluster layout that wraps 6/7 items as 6+1.

## Section accent color variables
- For multi-section sites, define per-section colors as CSS variables: `--s1` through `--s5` (or more if needed).
- Use these on section number badges, top borders, card borders, and tab buttons.
- Example: `--s1: #06B6D4; --s2: #F59E0B; --s3: #8B5CF6; --s4: #10B981; --s5: #EC4899;`

## Section number badges
- Each section header gets a numbered badge: `<div class="section-number">01</div>`.
- Styled with `width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 18px; color: var(--bg);` and a gradient background using that section's accent color.

## Tabbed sections
- When a section has multiple sub-topics (e.g. cashier + AI + data analysis under one chapter), use a tab bar.
- Tab bar: horizontal row of pill-shaped buttons, active tab gets the section's accent color.
- Only one `.tab-panel` visible at a time, toggled by JS.

## Interactive simulation patterns

### Cart with product selection (cashier pattern)
- Product grid: clickable buttons with emoji + name + price, "إضافة" badge.
- Cart display: items with qty controls (+ / -), remove button (🗑️), subtotal, discount row (hidden until triggered), final total.
- Discount logic: auto-apply when subtotal > threshold (e.g. 10% off over 500 EGP).
- Reset button: clears cart, hides totals, hides receipt.
- Print receipt button: generates a monospace receipt card (dashed border, `direction: ltr`) showing items as `Name Price × Qty`, original total, discount (if any), final total, "Thank you!".

### Teachable Machine simulator
- Training view: 3 class cards side by side, each with a grid of ~8 emoji thumbnails and a label.
- "Train Model" button → progress bar animation → switches to test view after completion.
- Test view: test image + name on left, probability bars (horizontal, per class) on right that animate filling in.
- Results table: 3 rows (Image | Prediction | Confidence), one deliberately wrong prediction included.

### Parking simulation
- LED bulbs: 4 colored bulbs (green, red, yellow, blue) with `.bulb` base class and `.on-green` / `.on-red` etc. for lit state.
- Counter display: large number showing current count.
- Entry/Exit buttons: trigger LED blink animation (yellow for entry, blue for exit) via setTimeout.
- IO diagram: 3 boxes (Inputs → Processing → Outputs) that light up in sequence on each action.

### Step-by-step reveal (Next/Back)
- Steps stacked vertically, only the current step is visible (`.step-card.active`).
- "التالي" / "السابق" buttons with a step counter (`1 / 4`).
- JS: `stepIdx` tracks current, buttons call `stepDir(+1)` or `stepDir(-1)`.

### Bar chart with reveal
- Bars built dynamically from data array, height proportional to max value.
- Initially dimmed (opacity 0.7), values hidden.
- "اكشف التحليل" button reveals all bars, highlights max (green) and min (red), shows conclusion text.
- "إعادة" button resets to initial state.

## Common mistakes box
- Every section ends with an error box: `<div class="error-box">`.
- Contains `⚠️ أخطاء شائعة` heading + bullet list of common student mistakes.
- Styled with `border: 1px solid rgba(255,71,87,.2); background: rgba(255,71,87,.05); border-radius: 12px; padding: 16px;`.

## Branding
- Logo files are provided in `assets/` (`bilal-icon.webp` = icon-only mark, `bilal-wordmark.webp` = full "Bilal" wordmark). Convert to base64 and embed as `<img>` — do not attempt to redraw the logo as SVG.
- The logo files have a solid `#193cff` background baked into the image (not transparent). Display them inside a small rounded container/badge sized to fit the logo closely, rather than placing the raw square directly on the page background — this reads as intentional rather than a stray colored box.
- **The logo must be wrapped in a link pointing to the project root `index.html`.** The relative `href` depends on the HTML file's depth in the folder tree (e.g. `../../../../index.html` for a file nested 4 levels deep). Adjust accordingly. The link should have an `aria-label` in Arabic (e.g. `aria-label="الرئيسية"`).
- Header and footer both carry the brand: header can use the icon or wordmark; footer must include the logo plus a short, simple encouraging sentence for students (in Egyptian Arabic).
- Standard logo markup and sizing (use these exact classes and values so the logo is identical across every site):
  - Header: `<a href="../../../../index.html" aria-label="الرئيسية"><img class="nav-logo" src="data:image/webp;base64,..." alt="logo"></a>` with CSS `.nav-logo { width: 36px; height: 36px; border-radius: 10px; object-fit: contain; }`
  - Footer: `<img class="footer-logo" src="data:image/webp;base64,..." alt="logo">` with CSS `.footer-logo { height: 40px; border-radius: 8px; }`
  - The HTML `class` MUST match the CSS class exactly (`.nav-logo`, NOT `.logo-nav`). If a mismatched class is used, the browser renders the image at its full natural size (huge). After embedding the logo, verify the `<img>` has a matching CSS rule with an explicit size.

## Misc
- If given content is very long (spans more than one lesson), the site should still be built as one file covering the full scope — this is a warning-only case, not a refusal case, and is handled upstream in the Q&A (Bilal is warned before generation, not by the site build itself).
- HTML filename: auto-generate an English slug from the lesson title (lowercase, hyphen-separated, no spaces) — e.g. "loops-and-iteration.html".

## Activities vs. Quizzes — distinct interaction pattern
- **In-section quizzes**: short recall checks embedded within a section. Use the per-question immediate color-feedback pattern (green/red + explanation + skip button). These are interactive and guide the student question by question.
- **End-of-lesson exercises**: full sets of questions at the end of the lesson. Use the self-work-then-reveal pattern (all questions visible, no feedback until the student clicks "اعرض كل الإجابات", then all answers appear at once). Do not mix the two patterns on the same question block.
- **Activity simulations** (cart, parking, Teachable Machine, etc.): these are interactive demos, not Q&A. They follow their own simulation patterns from the Interactive simulation patterns section below.

## Live Code Preview pattern (for web development lessons — HTML/CSS/JS)
When lesson content is about web development itself (not a diagram-based CS concept), the most powerful interaction is genuine live rendering, not an illustration of one. Use this pattern:
- A code panel (`dir="ltr"`, monospace, light keyword/string/tag color-tinting via `<span>` classes) showing the HTML/CSS/JS.
- A live preview `<iframe>` whose `srcdoc` is set from the code panel's content via JS — this renders for real, not a mockup screenshot.
- For step comparisons (e.g. "same HTML, now with CSS applied"), show two iframes side by side or one iframe toggled between versions.
- For students' own hands-on practice, make the code panel genuinely editable (textarea or simple contenteditable) so the iframe updates live as they type — this is the direct digital equivalent of Bilal's classroom technique of progressively uncommenting sections of a real `.html` file; the interactive version lets each student control the reveal themselves.
- For non-code conceptual walkthroughs sourced as "Simulation" logs (packet journeys, DNS lookups, request/response cycles, render timelines) — these are not real code, so render them as an animated terminal/log-style card instead (lines appearing in sequence, monospace, success lines in `--accent`), not as a live iframe.
